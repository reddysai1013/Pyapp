# sherpa-observability

Code/IaC for Sherpa's observability infrastructure

## Projects

* platform - IaC for the observability platform resources (Coralogix/Checkly)
* agents - Configuration for agents deployed to hosts for collecting metrics/logs

